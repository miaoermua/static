# Unlock CN GMS

部分国行手机内置 GMS ，但是某些功能无法使用，比如设备无法在 web 版 Google play 中显示，无法开启 Location History 服务。

该模块通过去除 ```<feature name="cn.google.services" />``` 来实现去除国行 GMS 的限制

去除这个限制也能解决近期 Google Play 下载 404 的问题
