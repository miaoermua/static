# 此模板由碎念制作 ┋ This template is made by Sui Nian
# QQ邮箱（主用）：2971802058@qq.com ┋ QQ Postbox（main）：2971802058@qq.com
# QQ邮箱（备用）：2177119873@qq.com ┋ QQ Postbox（spare）：2177119873@qq.com
# 谷歌邮箱：suinian666@gmail.com ┋ gmail：suinian666@gmail.com
# 酷安：http://www.coolapk.com/u/1315644 ┋ Coolapk：http://www.coolapk.com/u/1315644

# 这个脚本会在删除模块的时候执行